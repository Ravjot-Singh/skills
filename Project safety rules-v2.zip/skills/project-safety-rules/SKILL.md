---
name: "project-safety-rules"
description: Adds the user's standard safety rules (no git commands without asking; never read .env, use .env.example instead) to the project's CLAUDE.md. Use this skill whenever a new coding project is being started or set up — e.g. "start a new project", "scaffold a React/Node/Python app", "init a repo", "set up a new codebase", "create a CLAUDE.md", running /init, or beginning work in a folder that has no CLAUDE.md yet — even if the user doesn't mention CLAUDE.md or these rules explicitly.
---

# Project Safety Rules

When a new coding project starts, make sure its `CLAUDE.md` contains the user's standing rules. These rules protect the user's repository history and secrets, so they should be in place before any other project work happens.

## The rules block

Insert exactly this section (keep the heading so it can be detected later):

```markdown
## Project Safety Rules

- Do not perform any git commands without asking first.
- Never read the `.env` file. Instead, use `.env.example` as the reference for any environment-related activities.
```

## Steps

1. **Find the project root** — the folder the new project lives in (where `package.json`, `pyproject.toml`, `.git`, etc. are or will be). If unclear, use the current working directory.
2. **Check for `CLAUDE.md`** at the project root.
   - **Missing:** create it with a `# CLAUDE.md` title followed by the rules block.
   - **Exists:** if it already contains the heading `## Project Safety Rules`, leave it alone. Otherwise append the rules block to the end (preceded by a blank line). Never remove or rewrite existing content.
3. **Briefly tell the user** the rules were added (or were already present).
4. **Follow the rules yourself for the rest of the session**:
   - Before running any `git` command (init, add, commit, push, checkout, etc.), ask the user and wait for approval. This includes `git init` during scaffolding — many project generators (`create-react-app`, `cargo new`, etc.) run git automatically, so pass their no-git flag (e.g. `--no-git`, `--vcs none`) or ask first.
   - Do not open, cat, grep, or otherwise read `.env`. If environment configuration is needed, read `.env.example`; if it doesn't exist, ask the user which variables are needed rather than peeking at `.env`.

## Why

Git commands can rewrite history, push code, or create commits the user didn't intend, so the user wants to approve them. `.env` files contain real secrets (API keys, passwords) that shouldn't enter the conversation; `.env.example` has the same variable names without the sensitive values.
